import React from "react";
import Header from "../../Components/organism/Header";
import About from "../../Components/organism/About";
import ToolKit from "../../Components/organism/Toolkits";
import Tools from "../../Components/organism/Tools";
import Resources from "../../Components/organism/Resources";
import Subscribe from "../../Components/organism/Subscribe";
import Footer from "../../Components/organism/Footer";

export default function LandingPage() {
  return (
    <div>
      <Header />
      <About />
      <ToolKit />
      <Resources />
      <Tools />
      <Subscribe />
      <Footer />
    </div>
  );
}
