import React from "react";
import Navbar from "../../molecules/Navbar";
import HeaderImage from "../../../assets/img/HeaderImage.png";
import Container from "../../atoms/Container";
import { BiChevronRight } from "react-icons/bi";
import Button from "../../atoms/Button";
import "./header.scss";

const Header = () => {
  return (
    <Container>
      <div id="home" className="header">
        <Navbar />
        <div className="header_intro">
          <div className="header_intro_text">
            <h1 className="header_intro_text_title">Vigor Toolkits</h1>
            <h2 className="header_intro_text_subTitle">
              Your Data is in Safe Hands
            </h2>
            <p className="header_intro_text_description">
              Vigor Toolkits recommend FREE on-demand data and platform security
              guidelines for data and technology-driven small and medium-sized
              organizations.
            </p>
            <a href="#vigor" className="CTA">
              <span> Learn More </span>
              <span>
                <BiChevronRight className="chevron" />
              </span>
            </a>
          </div>
          <div className="header_intro_image">
            <img src={HeaderImage} alt="vigor_header_image" />
          </div>
        </div>
      </div>
    </Container>
  );
};

export default Header;
