import React, { useState } from "react";
import ICOImage from "../../../assets/img/ICO_Img.png";
import UKGDPRImage from "../../../assets/img/UKGDPR_Img.png";
import EUImage from "../../../assets/img/EU_COOKIE_DIRECTIVE_Img.png";
import ArrowForward from "../../../assets/svg/longArrowRed.svg";
import Container from "../../atoms/Container";
import Modal from "../../molecules/modals/Modal";

import { BsArrowRightShort } from "react-icons/bs";

import "./resources.scss";

export default function Resources() {
  const [modal, setModal] = useState("");

  return (
    <>
      {modal === "EU" ? (
        <Modal
          setModal={setModal}
          title="EU COOKIE DIRECTIVE"
          info="The International Information Security Standard"
          src="https://media.istockphoto.com/id/1364958689/video/top-view-from-the-office-window-on-the-city-road-and-parking.mp4?s=mp4-640x640-is&k=20&c=8KZ7Qly6EYjR9I7JD3RPmxBMuRv3LCSSu0C5qC0bqR8="
          description="Lorem ipsum dolor sit amet consectetur. Nec lobortis venenatis fermentum tincidunt. Dis eu ultrices justo ullamcorper odio risus sed. Condimentum ipsum condimentum tincidunt felis nisl aliquam diam porttitor ornare. Dignissim id posuere tellus ridiculus tempor auctor quis. Neque dictum quam sit urna sed neque non nulla."
        />
      ) : (
        ""
      )}
      {modal === "UKGDPR" ? (
        <Modal
          setModal={setModal}
          title="UKGDPR"
          info="UK General Data Protection Regulation"
          src="https://media.istockphoto.com/id/1406349059/video/young-man-sitting-on-motorcycle-before-starting-it-and-speeding-away-a-young-man-in-sport.mp4?s=mp4-640x640-is&k=20&c=R8pHqWgdUkd88vxpwj3lZBWx8gMbDwX7Dj32mrDQ-ag="
          description="Lorem ipsum dolor sit amet consectetur. Nec lobortis venenatis fermentum tincidunt. Dis eu ultrices justo ullamcorper odio risus sed. Condimentum ipsum condimentum tincidunt felis nisl aliquam diam porttitor ornare. Dignissim id posuere tellus ridiculus tempor auctor quis. Neque dictum quam sit urna sed neque non nulla."
        />
      ) : (
        ""
      )}
      {modal === "ICO" ? (
        <Modal
          setModal={setModal}
          title="ICO"
          info="Information Commissioners Office"
          src="https://media.istockphoto.com/id/1355808507/video/close-up-view-of-man-connecting-charging-cable-to-charging-station-for-electric-car-sweden.mp4?s=mp4-640x640-is&k=20&c=L0gHTPtRjedE0j6uYNFcl4o0abaMA6e_8Wo9W3cfSbQ="
          description="Lorem ipsum dolor sit amet consectetur. Nec lobortis venenatis fermentum tincidunt. Dis eu ultrices justo ullamcorper odio risus sed. Condimentum ipsum condimentum tincidunt felis nisl aliquam diam porttitor ornare. Dignissim id posuere tellus ridiculus tempor auctor quis. Neque dictum quam sit urna sed neque non nulla."
        />
      ) : (
        ""
      )}

      <Container>
        <div id="resources" className="resources">
          <h5 className="resources_name">Resources</h5>
          <h2 className="resources_title">Data Protection Regulation</h2>
          <div className="resources_details">
            <div className="resources_details_image">
              <img src={EUImage} alt="EU_COOKIE_DIRECTIVE_Img" />
              <div onClick={() => setModal("EU")} className="modalToggler">
                <span>Learn More</span>
                <span>
                  <BsArrowRightShort className="arrow" />
                </span>
              </div>
            </div>
            <div className="resources_details_image">
              <img src={UKGDPRImage} alt="UKGDPR_Img" />
              <div onClick={() => setModal("UKGDPR")} className="modalToggler">
                <span>Learn More</span>
                <span>
                  <BsArrowRightShort className="arrow" />
                </span>
              </div>
            </div>
            <div className="resources_details_image">
              <img src={ICOImage} alt="ICO_Img" />
              <div onClick={() => setModal("ICO")} className="modalToggler">
                <span>Learn More</span>
                <span>
                  <BsArrowRightShort className="arrow" />
                </span>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </>
  );
}
