import React, { useRef, useState } from "react";
import "./toolkit.scss";
import Container from "../../atoms/Container";
import Video from "../../../assets/video/video.mp4";
import { AiFillPlayCircle } from "react-icons/ai";

const ToolKit = () => {
  const videoRef = useRef();
  const [videoControls, setVideoControls] = useState(true);

  const handlePlay = () => {
    setVideoControls(false);
    videoRef.current.play();
  };
  const handlePause = () => {
    setVideoControls(true);
    videoRef.current.pause();
  };

  return (
    <Container>
      <div id="vigor" className="toolkits">
        <h5 className="toolkits_name">Vigor</h5>
        <h2 className="toolkits_title">Vigor Toolkits</h2>
        <div className="toolkits_video">
          {videoControls ? (
            <span className="toolkits_video_icon" onClick={handlePlay}>
              <AiFillPlayCircle className="playIcon" />
            </span>
          ) : (
            <span className="toolkits_video_icon" onClick={handlePause}>
              <AiFillPlayCircle className="playIcon" />
            </span>
          )}
          <video src={Video} loop muted className="video" ref={videoRef} />
        </div>
      </div>
    </Container>
  );
};

export default ToolKit;
