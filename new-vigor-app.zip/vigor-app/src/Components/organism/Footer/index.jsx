import React, { useState } from "react";
import "./footer.scss";
import footerImg from "../../../assets/img/contactUs.png";
import Button from "../../atoms/Button";
import Container from "../../atoms/Container";
import axios from "axios";

const Footer = () => {
  const [email, setEmail] = useState({
    email: "",
  });
  const [response, setResponse] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setResponse("Sending...");
    try {
      const data = await axios.post(
        "https://newsletters-api.adaptable.app/subscribers",
        email
      );
      setResponse(data.data.message);
      setTimeout(() => {
        setResponse("");
      }, 5000);
      setEmail({ ...email, email: "" });
      console.log(data);
    } catch (error) {
      setResponse(error.message);
      setTimeout(() => {
        setResponse("");
      }, 5000);
      // console.log(error);
    }
  };

  return (
    <section id="section" className="footer">
      <Container>
        <div className="footer_content">
          <div className="footer_content_image">
            <img src={footerImg} />
          </div>
          <div className="footer_content_details">
            <h2>Contact Us</h2>
            <p className="contact">Contact</p>
            <p className="footer_content_details_text">contact@company.com</p>
            <p className="footer_content_details_text">(406) 555-0120</p>

            <form onSubmit={handleSubmit}>
              <input
                type="input"
                className="form-input"
                placeholder="Email"
                value={email.email}
                onChange={(e) => setEmail({ ...email, email: e.target.value })}
              />
              <Button type="submit" content="Subscribe now" />
              <p className="response">{response}</p>
            </form>
          </div>
        </div>
      </Container>

      <hr className="hr" />
      <p className="footer_copyright">© Copyright 2022 All rights reserved.</p>
    </section>
  );
};

export default Footer;
