import React, { useState } from "react";
import Container from "../../atoms/Container";
import Modal from "../../molecules/modals/Modal";
import "./tools.scss";

export default function Tools() {
  const [modal, setModal] = useState("");

  return (
    <>
      {modal === "PMT" ? (
        <Modal
          setModal={setModal}
          title="Password Management Tools"
          src="https://media.istockphoto.com/id/1364958689/video/top-view-from-the-office-window-on-the-city-road-and-parking.mp4?s=mp4-640x640-is&k=20&c=8KZ7Qly6EYjR9I7JD3RPmxBMuRv3LCSSu0C5qC0bqR8="
          description="These tools help you manage and generate complex passwords across multiple online accounts in a single software. Other functions include password reset, two-factor authentication, and many more. "
        />
      ) : (
        ""
      )}
      {modal === "Firewalls" ? (
        <Modal
          setModal={setModal}
          title="EU COOKIE DIRECTIVE"
          src="https://media.istockphoto.com/id/1364958689/video/top-view-from-the-office-window-on-the-city-road-and-parking.mp4?s=mp4-640x640-is&k=20&c=8KZ7Qly6EYjR9I7JD3RPmxBMuRv3LCSSu0C5qC0bqR8="
          description="These tools are an essential barrier between your firm’s private network and the public internet. They monitor and filter incoming and outgoing network traffic to bounce off possible network access or infiltration. For recommended tools"
        />
      ) : (
        ""
      )}
      {modal === "Audit" ? (
        <Modal
          setModal={setModal}
          title="Data Audit of your Web page"
          src="https://media.istockphoto.com/id/1364958689/video/top-view-from-the-office-window-on-the-city-road-and-parking.mp4?s=mp4-640x640-is&k=20&c=8KZ7Qly6EYjR9I7JD3RPmxBMuRv3LCSSu0C5qC0bqR8="
          description="Web security audits list all known vulnerabilities, misconfigurations, loopholes, security weaknesses, and gaps in the IT infrastructure. They are also capable of detecting malware and website defacement. Furthermore, they shed light on flaws in business logic and other previously unknown vulnerabilities."
        />
      ) : (
        ""
      )}
      {modal === "FST" ? (
        <Modal
          setModal={setModal}
          title="File Shredding Tools"
          src="https://media.istockphoto.com/id/1364958689/video/top-view-from-the-office-window-on-the-city-road-and-parking.mp4?s=mp4-640x640-is&k=20&c=8KZ7Qly6EYjR9I7JD3RPmxBMuRv3LCSSu0C5qC0bqR8="
          description="These toolkits will help your firm take file deletion to the next level by actually overwriting the space once occupied by the deleted file. Need tools that permanently delete files on your computer?"
        />
      ) : (
        ""
      )}
      {modal === "CMT" ? (
        <Modal
          setModal={setModal}
          title="EU COOKIE DIRECTIVE"
          src="https://media.istockphoto.com/id/1364958689/video/top-view-from-the-office-window-on-the-city-road-and-parking.mp4?s=mp4-640x640-is&k=20&c=8KZ7Qly6EYjR9I7JD3RPmxBMuRv3LCSSu0C5qC0bqR8="
          description="Consent Management Tools help you, prompt users, for consent, rather than manually. Need tools that help your website or app be GDPR-compliant?"
        />
      ) : (
        ""
      )}

      <Container>
        <div id="tools" className="tools">
          <h5 className="tools_name">Tools</h5>
          <h2 className="tools_title">Platform Security Resources</h2>
          <div className="tools_cards cards">
            <div className="tools_cards_wrapper">
              <div className="tools_cards_wrapper_item">
                <h3 className="title">Password Management Tools</h3>
                <p className="description">
                  These tools help you manage and generate complex passwords
                  across multiple online accounts in a single software. Other
                  functions include password reset, two-factor authentication,
                  and many more.{" "}
                  <span onClick={() => setModal("PMT")}>Click here</span> for a
                  list of some of our favorite password management tools.
                </p>
              </div>
              <div className="tools_cards_wrapper_item">
                <h3 className="title">Firewalls</h3>
                <p className="description">
                  These tools are an essential barrier between your firm’s
                  private network and the public internet. They monitor and
                  filter incoming and outgoing network traffic to bounce off
                  possible network access or infiltration. For recommended
                  tools,
                  <span onClick={() => setModal("Firewalls")}> click here</span>
                  .
                </p>
              </div>
              <div className="tools_cards_wrapper_item">
                <h3 className="title">Data Audit of your Web page</h3>
                <p className="description">
                  Web security audits list all known vulnerabilities,
                  misconfigurations, loopholes, security weaknesses, and gaps in
                  the IT infrastructure. They are also capable of detecting
                  malware and website defacement. Furthermore, they shed light
                  on flaws in business logic and other previously unknown
                  vulnerabilities.{" "}
                  <span onClick={() => setModal("Audit")}>Click here</span> for
                  a list of some of our favorite Data Auditing
                </p>
              </div>

              <div className="tools_cards_wrapper_item">
                <h3 className="title">File Shredding Tools</h3>
                <p className="description">
                  These toolkits will help your firm take file deletion to the
                  next level by actually overwriting the space once occupied by
                  the deleted file. Need tools that permanently delete files on
                  your computer?{" "}
                  <span onClick={() => setModal("FST")}> click here</span>.
                </p>
              </div>
              <div className="tools_cards_wrapper_item">
                <h3 className="title">Consent Management Tools</h3>
                <p className="description">
                  Consent Management Tools help you, prompt users, for consent,
                  rather than manually. Need tools that help your website or app
                  be GDPR-compliant?{" "}
                  <span onClick={() => setModal("CMT")}> here are a few.</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </>
  );
}
