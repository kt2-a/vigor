import React from "react";
import Container from "../../atoms/Container";
import { BiChevronRight } from "react-icons/bi";
import "./subscribe.scss";

export default function Subscribe() {
  return (
    <Container>
      <div className="subscribe">
        <div className="subscribe_content">
          <h5>SUBSCRIBE TO VIGOR FOR FREE</h5>
          <h2>Get updates on security trends with Vigor</h2>
          <button className="CTA">
            <span> Subscribe now </span>
            <span>
              <BiChevronRight className="chevron" />
            </span>
          </button>
        </div>
      </div>
    </Container>
  );
}
