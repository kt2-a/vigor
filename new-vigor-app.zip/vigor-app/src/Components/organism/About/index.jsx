import React from "react";
import aboutImg from "../../../assets/img/AboutImage.png";
import CountCards from "../../molecules/CountCard";
import Container from "../../atoms/Container";
import Button from "../../atoms/Button";
import { MdOutlineLockOpen } from "react-icons/md";
import "./about.scss";

const About = () => {
  return (
    <Container>
      <section id="about" className="about">
        <h5 className="about_name">ABOUT</h5>
        <h2 className="about_title">Project Background</h2>

        <div className="about_contentWrapper">
          <div className="about_contentWrapper_image">
            <img src={aboutImg} />
          </div>
          <div className="about_contentWrapper_description">
            <span className="iconWrapper">
              <MdOutlineLockOpen className="lock" />
            </span>
            <h3>Cybersecurity research to ease your mind.</h3>
            <p className="about_contentWrapper_description_text">
              We carry out extensive research obuttonn cybersecurity toolkits
              and data protection regulations for technology-oriented small and
              medium businesses in England. Our mission is to close information
              and technological knowledge gaps that increase the risk of
              security breaches and the loss of sensitive business or customer
              data in small and medium-sized businesses.
            </p>
            <div className="about_contentWrapper_description_counts">
              <CountCards
                count="08+"
                content1="Resources and"
                content2="Toolkits"
              />
              <CountCards
                count="80+"
                content1="Resources "
                content2="contributions"
              />
              <CountCards
                count="5+"
                content1="Collaborated "
                content2="Companies"
              />
            </div>
            <div className="about_contentWrapper_description_button">
              <Button content="Download PDF" />
            </div>
            <p className="about_contentWrapper_description_info">
              Download full information and stats on the Vigor Project
            </p>
          </div>
        </div>
      </section>
    </Container>
  );
};

export default About;
