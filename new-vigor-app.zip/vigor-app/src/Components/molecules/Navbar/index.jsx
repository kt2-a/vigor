import React from "react";
import "./Navbar.scss";
import Container from "../../atoms/Container";
import { GiHamburgerMenu } from "react-icons/gi";

export default function Navbar() {
  return (
    <div className="nav_container">
      <Container>
        <header className="navbar" id="header">
          <div className="logo">
            <h2>Vigor Toolkits</h2>
          </div>
          <span className="items">
            <label htmlFor="check">
              <span className="menu">
                <GiHamburgerMenu className="bars" />
              </span>
            </label>
            <input type="checkbox" id="check" />

            <nav className="nav-links">
              <ul>
                <li>
                  <a href="#home" className="anchor">
                    Home
                  </a>
                </li>
                <li>
                  <a href="#about" className="anchor">
                    About
                  </a>
                </li>
                <li>
                  <a href="#vigor" className="anchor">
                    Vigor
                  </a>
                </li>
                <li>
                  <a href="#resources" className="anchor">
                    Resources
                  </a>
                </li>
                <li>
                  <a href="#tools" className="anchor">
                    Tools
                  </a>
                </li>
              </ul>
            </nav>
            {/* Below is the toggle icon */}

            {/* <span className="toggle">
              <i className="fa fa-moon"></i>
            </span> */}
          </span>
        </header>
      </Container>
    </div>
  );
}
