import React from "react";
import "./countCard.scss";

const CountCards = (props) => {
  return (
    <>
      <div className="counter">
        <h2>{props.count} </h2>
        <p>
          {props.content1} <br />
          {props.content2}
        </p>
      </div>
    </>
  );
};

export default CountCards;
