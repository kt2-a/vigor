import React, { useRef, useState } from "react";
import ModalContainer from "..";
import { ImCancelCircle } from "react-icons/im";
import { BsArrowRightShort } from "react-icons/bs";
import { AiFillPlayCircle } from "react-icons/ai";
import "./Modal.scss";

export default function EUModal({
  setModal,
  title,
  info,
  src,
  description,
  viewMore,
}) {
  const [videoControls, setVideoControls] = useState(true);
  const videoRef = useRef();

  const handlePlay = () => {
    setVideoControls(false);
    videoRef.current.play();
  };
  const handlePause = () => {
    setVideoControls(true);
    videoRef.current.pause();
  };

  return (
    <ModalContainer>
      <div className="Modal">
        <div className="Modal_head">
          <h3 className="Modal_head_title">{title}</h3>
          <span className="Modal_head_icon" onClick={() => setModal("")}>
            <ImCancelCircle className="cancel" />
          </span>
        </div>
        <p className="Modal_info">{info}</p>
        <div className="Modal_video">
          {videoControls ? (
            <span className="Modal_video_icon" onClick={handlePlay}>
              <AiFillPlayCircle className="playIcon" />
            </span>
          ) : (
            <span className="Modal_video_icon" onClick={handlePause}>
              <AiFillPlayCircle className="playIcon" />
            </span>
          )}
          <video src={src} loop muted className="video" ref={videoRef} />
        </div>
        <p className="Modal_description">{description}</p>
        <a href={viewMore} target="_blank" className="Modal_viewMore">
          <span>View More</span>
          <span>
            <BsArrowRightShort className="arrow" />
          </span>
        </a>
      </div>
    </ModalContainer>
  );
}
