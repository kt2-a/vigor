import React from "react";
import "./modalContainer.scss";

export default function ModalContainer({ children }) {
  return (
    <div className="modalContainer">
      <div className="modalContainer_item">{children}</div>
    </div>
  );
}
