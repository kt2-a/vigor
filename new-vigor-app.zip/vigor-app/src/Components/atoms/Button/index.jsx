import React from "react";
import "./button.scss";
import { BsArrowRightShort } from "react-icons/bs";
import { BiChevronRight } from "react-icons/bi";

const Button = (props) => {
  return (
    <button type={props.type} className="button">
      <span className="button_text">{props.content}</span>
      <span className="button_icon">
        {props.icon ? (
          <BsArrowRightShort className="arrow" />
        ) : (
          <BiChevronRight className="chevron" />
        )}
      </span>
    </button>
  );
};

export default Button;
