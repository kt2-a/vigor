// import './App.css';
// import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import LandingPage from "./Pages/Home";

function App() {
  return (
    <div className="App">
      <LandingPage />
      {/* <Router>
      <Switch>
        <Route exact path="/" component="Banner" />
        
      </Switch>
    </Router> */}
    </div>
  );
}

export default App;
